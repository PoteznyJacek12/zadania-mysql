<?php
$polaczenie=mysqli_connect("localhost", "root",
"", "sklep")


?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hurtownia Szkolna</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header>
        <h1>Hurtownia z najlepszymi cenami</h1>
    </header>
    <section id="lewy">
        <h2>Nasze ceny</h2>
        <table>
            <?php
            $zapytanie1="SELECT towary.nazwa,towary.cena FROM towary LIMIT 4;";
            $zapytanie11=mysqli_query($polaczenie,$zapytanie1);
            while($wynik=mysqli_fetch_assoc($zapytanie11)){
                echo "<tr>";
                echo "<th>".$wynik['nazwa']."</th>";
                echo "<td>".$wynik['cena']."</td>";
                echo "</tr>";
            }


            ?>
            
        </table>
    </section>
    <section id="srodek">
        <h2>Koszt zakupów</h2>
        <form action="index.php" method="post">
        <label for="lista">wybierz artykuł:</label>
        <select name="lista" id="lista">
            <option value="">Zeszyt 60 kartek</option>
            <option value="">Zeszyt 32 kartek</option>
            <option value="">Cyrkiel</option>
            <option value="">Linijka 30 cm</option>
        </select><br>
        <label for="ilosc">liczba sztuk:</label>
        <input type="number" name="ilosc" id="ilosc"><br>
        <button type="submit">Oblicz</button>

        </form>
    </section>
    <section id="prawy">
        <h2>Kontakt</h2>
        <img src="zakupy.png" alt="hurtownia">
        <p>email:<a href="hurt@poczta2.pl">hurt@poczta2.pl</a></p>
    </section>
    <footer>
        <h4>Witrynę wykonał:JACEKKKK</h4>
    </footer>
</body>
</html>

<?php
mysqli_close($polaczenie)
?>